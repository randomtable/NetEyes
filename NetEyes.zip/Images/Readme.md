Folder for media and support files
